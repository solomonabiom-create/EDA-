"""
Builds index.html for Solomon's circuit-fundamentals portfolio.
Light "engineering lab notebook" aesthetic -- deliberately distinct from the
other portfolios. All renders embedded as base64 so the page is self-contained.
Run:  python3 scripts/build_site.py
"""
import base64
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
REN = os.path.join(ROOT, "renders")


def png(name):
    with open(os.path.join(REN, name), "rb") as f:
        return "data:image/png;base64," + base64.b64encode(f.read()).decode()


IMG = {k: png(v) for k, v in {
    "ohm": "01_ohms_law.png", "div": "01_voltage_divider.png",
    "rc": "02_rc_response.png", "step": "02_rc_step.png",
    "led": "03_led_sweep.png", "rchoice": "03_resistor_choice.png",
}.items()}

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Solomon Abiom &mdash; Circuit Fundamentals Notebook</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Newsreader:ital,wght@0,400;0,500;1,400&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root{
  --paper:#faf6ee; --card:#fffdf8; --ink:#23201a; --ink-soft:#6a6356;
  --rule:#ddd3c0; --blue:#2f5d8a; --brick:#b8552f; --pencil:#4a4534;
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
@media (prefers-reduced-motion:reduce){html{scroll-behavior:auto}}
body{
  background:var(--paper);color:var(--ink);
  font:400 18px/1.66 "Newsreader",Georgia,serif;-webkit-font-smoothing:antialiased;
  /* faint ruled-notebook lines */
  background-image:linear-gradient(var(--rule) 1px,transparent 1px);
  background-size:100% 32px;background-position:0 -1px;
}
.wrap{max-width:940px;margin:0 auto;padding:0 24px;
  background:linear-gradient(90deg,transparent 38px,#e9c9bd 38px,#e9c9bd 39px,transparent 39px);}
@media(max-width:680px){.wrap{background:none}}
.inner{padding-left:30px}
@media(max-width:680px){.inner{padding-left:0}}
a{color:var(--blue);text-underline-offset:3px}
a:focus-visible{outline:2.5px solid var(--brick);outline-offset:3px}
.mono{font-family:"IBM Plex Mono",monospace;font-size:.82em}

header.hero{padding:60px 0 38px}
.meta-top{font-family:"IBM Plex Mono",monospace;font-size:.78rem;letter-spacing:.04em;
  color:var(--ink-soft);text-transform:uppercase;margin-bottom:18px}
.eqs{display:flex;flex-wrap:wrap;gap:14px 30px;margin:22px 0 26px;
  font-family:"Fraunces",serif;font-size:clamp(1.1rem,2.4vw,1.5rem);color:var(--blue)}
.eqs b{color:var(--brick);font-weight:600}
h1{font-family:"Fraunces",serif;font-weight:700;font-size:clamp(2.1rem,5vw,3.4rem);
  line-height:1.08;letter-spacing:-.01em;margin:8px 0 14px}
.lede{font-size:1.12rem;color:var(--ink);max-width:48em;line-height:1.7}
.lede b{font-weight:600}
.note{margin-top:16px;font-family:"Newsreader",serif;font-style:italic;
  color:var(--ink-soft);font-size:1rem;max-width:46em}
.hlinks{margin-top:22px;display:flex;flex-wrap:wrap;gap:8px 22px;
  font-family:"IBM Plex Mono",monospace;font-size:.84rem}
.chips{margin-top:20px;display:flex;flex-wrap:wrap;gap:7px}
.chip{border:1px solid var(--rule);background:var(--card);border-radius:3px;
  padding:4px 11px;font-family:"IBM Plex Mono",monospace;font-size:.74rem;color:var(--ink-soft)}

section.entry{padding:40px 0;border-top:1px solid var(--rule)}
.fig-no{font-family:"IBM Plex Mono",monospace;font-size:.76rem;letter-spacing:.08em;
  color:var(--brick);text-transform:uppercase}
h2{font-family:"Fraunces",serif;font-weight:600;font-size:clamp(1.4rem,3vw,1.95rem);
  margin:6px 0 14px;letter-spacing:-.005em}
.entry p{max-width:60em;color:var(--ink);margin-bottom:14px}
.entry p b{font-weight:600}
figure.plate{margin:18px 0;border:1px solid var(--rule);background:var(--card);
  padding:10px;border-radius:4px;line-height:0;box-shadow:2px 2px 0 rgba(74,69,52,.06)}
figure.plate img{width:100%;height:auto;display:block}
figure.plate figcaption{font-family:"IBM Plex Mono",monospace;font-size:.74rem;
  color:var(--ink-soft);line-height:1.5;padding:8px 4px 2px;text-align:center}
.checked{display:inline-flex;align-items:baseline;gap:8px;
  font-family:"IBM Plex Mono",monospace;font-size:.84rem;color:var(--blue);
  background:var(--card);border:1px dashed var(--blue);padding:7px 13px;border-radius:4px;
  margin:6px 0 12px}
.checked b{color:var(--brick)}
.repro{font-family:"IBM Plex Mono",monospace;font-size:.76rem;color:var(--ink-soft);margin-top:6px}

footer{padding:42px 0 80px;border-top:2px solid var(--pencil)}
footer h2{margin-bottom:12px}
footer p{max-width:60em;color:var(--ink);margin-bottom:12px}
.sign{margin-top:18px;font-family:"IBM Plex Mono",monospace;font-size:.78rem;color:var(--ink-soft)}
</style>
</head>
<body>
<div class="wrap"><div class="inner">

<header class="hero">
  <div class="meta-top">Lab notebook &middot; circuit fundamentals &middot; Ngspice</div>
  <h1>Circuit fundamentals,<br>worked through in simulation</h1>
  <div class="eqs">
    <span><b>V</b> = I R</span>
    <span>&Sigma;V = 0</span>
    <span>fc = 1 / 2&pi;<b>R</b>C</span>
  </div>
  <p class="lede"><b>Solomon Abiom</b> &mdash; civil engineering graduate (B.Eng) and MSc Project Management
  student, revisiting the electrical-engineering fundamentals from my degree and working through them in
  <b>Ngspice</b> circuit simulation. Three worked entries: the basic laws, a first-order filter, and a
  practical component-sizing problem. Every result is checked against the textbook formula.</p>
  <p class="note">Grounded in the circuit theory from my engineering degree, worked through in simulation
  and checked against the underlying formulas - the foundation I'm building my EDA work on.</p>
  <div class="hlinks">
    <a href="mailto:solomonabiom@gmail.com">SOLOMONABIOM@GMAIL.COM</a>
    <span class="mono" style="color:var(--ink-soft)">GLASGOW, UK &middot; 2026</span>
  </div>
  <div class="chips">
    <span class="chip">Ngspice</span><span class="chip">Ohm's law</span><span class="chip">Kirchhoff</span>
    <span class="chip">RC filter</span><span class="chip">time constant</span><span class="chip">DC sweep</span>
    <span class="chip">transient</span><span class="chip">LTspice-compatible</span>
  </div>
</header>

<main>

<section class="entry">
  <div class="fig-no">Entry 01 &middot; the basic laws</div>
  <h2>Ohm's law &amp; Kirchhoff's voltage law</h2>
  <p>The starting point of every circuits course. First, <b>Ohm's law</b>: sweeping the supply across a fixed
  220&nbsp;&Omega; resistor, the current rises in a straight line and the slope of that line equals 1/R &mdash; the
  simulation sits exactly on the I&nbsp;=&nbsp;V/R prediction. Second, <b>Kirchhoff's voltage law</b>: in a series
  divider, the voltages across the two resistors must add up to the supply, which they do to the volt.</p>
  <div class="checked">verified &nbsp;<b>slope = 1/R</b>&nbsp; to 4 decimals &middot; divider voltages sum to 9.00 V</div>
  <figure class="plate"><img src="__OHM__" alt="Current vs supply voltage for a 220 ohm resistor; simulated points lie on the straight I=V/R line.">
    <figcaption>Fig. 01a &mdash; Ohm's law: simulated current vs the I = V/R line</figcaption></figure>
  <figure class="plate"><img src="__DIV__" alt="Bar chart of the two resistor voltages in a divider, summing to the 9 V supply.">
    <figcaption>Fig. 01b &mdash; Kirchhoff's voltage law: divider voltages add to the supply</figcaption></figure>
  <p class="repro">reproduce &rarr; <span class="mono">python3 scripts/01_ohms_kirchhoff.py</span></p>
</section>

<section class="entry">
  <div class="fig-no">Entry 02 &middot; a first filter</div>
  <h2>RC low-pass &mdash; smoothing a signal</h2>
  <p>A resistor and a capacitor make the simplest filter there is &mdash; the building block for cleaning up a
  noisy measurement. Seen in the frequency domain, it passes low frequencies and rejects high ones, with the
  <b>&minus;3&nbsp;dB cut-off</b> landing exactly where fc&nbsp;=&nbsp;1/(2&pi;RC) predicts. Seen in time, the
  output settles after a step with a smooth exponential, reaching 63% of its final value after one
  <b>time constant</b> &tau;&nbsp;=&nbsp;RC &mdash; the simulated curve hits that mark right on cue.</p>
  <div class="checked">verified &nbsp;<b>&minus;3 dB @ 1000 Hz</b>&nbsp; &middot; 63% reached at &tau; = 0.16 ms</div>
  <figure class="plate"><img src="__RC__" alt="Frequency response of an RC low-pass filter, with passband and stopband marked and the -3 dB cut-off at 1 kHz.">
    <figcaption>Fig. 02a &mdash; frequency response, with the &minus;3 dB cut-off marked</figcaption></figure>
  <figure class="plate"><img src="__STEP__" alt="Step response of the RC filter showing the exponential rise and the one-time-constant point at 63 percent.">
    <figcaption>Fig. 02b &mdash; step response and the R C time constant</figcaption></figure>
  <p class="repro">reproduce &rarr; <span class="mono">python3 scripts/02_rc_filter.py</span></p>
</section>

<section class="entry">
  <div class="fig-no">Entry 03 &middot; a real design choice</div>
  <h2>Sizing an LED current-limiting resistor</h2>
  <p>A practical first design task: pick the series resistor that sets a safe current through an LED, using
  R&nbsp;=&nbsp;(V<sub>supply</sub>&nbsp;&minus;&nbsp;V<sub>LED</sub>)&nbsp;/&nbsp;I. Using a real diode model so the
  LED's forward voltage is included, the simulation shows the current only flowing once the supply clears the
  forward voltage, and sweeping the resistor at 5&nbsp;V confirms which value lands the current in the safe
  <b>10&ndash;20&nbsp;mA</b> band. The rule-of-thumb 220&nbsp;&Omega; gives about 14&nbsp;mA &mdash; just as the
  hand calculation says.</p>
  <div class="checked">verified &nbsp;<b>220 &Omega; &rarr; 14 mA</b>&nbsp; at 5 V, inside the safe band</div>
  <figure class="plate"><img src="__LED__" alt="LED current and forward voltage as the supply is swept, for a fixed 220 ohm resistor.">
    <figcaption>Fig. 03a &mdash; LED current and forward voltage vs supply</figcaption></figure>
  <figure class="plate"><img src="__RCHOICE__" alt="LED current at a 5 V supply for seven resistor values, with the safe operating band shaded.">
    <figcaption>Fig. 03b &mdash; choosing the resistor: current vs resistor value</figcaption></figure>
  <p class="repro">reproduce &rarr; <span class="mono">python3 scripts/03_led_resistor.py</span></p>
</section>

</main>

<footer>
  <h2>About this notebook</h2>
  <p>I&rsquo;m a civil engineering graduate (B.Eng) currently completing an MSc in Project Management in Glasgow.
  Electrical and circuit theory was part of my engineering foundation, and this notebook is where I&rsquo;m
  putting that grounding into practice with circuit-simulation tools &mdash; describing each circuit, simulating
  it in Ngspice, and checking the result against the formula it should follow.</p>
  <p>Everything here is reproducible: each entry ships its SPICE netlists and a short Python script, and every
  figure is generated by the simulation that produced it. The netlists are standard SPICE and also run in LTspice.
  This is an honest starting point &mdash; foundations done properly, with room to build.</p>
  <p class="sign">SOLOMON ABIOM &middot; SOLOMONABIOM@GMAIL.COM &middot; NGSPICE / PYTHON &middot; GLASGOW, 2026</p>
</footer>

</div></div>
</body>
</html>
"""

page = (HTML
        .replace("__OHM__", IMG["ohm"]).replace("__DIV__", IMG["div"])
        .replace("__RC__", IMG["rc"]).replace("__STEP__", IMG["step"])
        .replace("__LED__", IMG["led"]).replace("__RCHOICE__", IMG["rchoice"]))

out = os.path.join(ROOT, "index.html")
with open(out, "w") as f:
    f.write(page)
print("wrote %s (%.1f MB)" % (out, os.path.getsize(out) / 1e6))
