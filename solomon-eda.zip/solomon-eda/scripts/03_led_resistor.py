"""
Project 3 -- A practical design: choosing an LED current-limiting resistor
One of the first real calculations an engineer does: pick the series resistor
that sets a safe current through an LED. The rule is

    R = (V_supply - V_led) / I_target

This project checks that rule in Ngspice two ways:

  (a) sweep the supply for a fixed resistor and watch the LED current and the
      voltage shared between the resistor and the LED (a real diode model, so
      the LED's forward-voltage behaviour is included, not idealised).
  (b) sweep the resistor value at a fixed 5 V supply and confirm the chosen
      resistor lands the current on target.

Run:     python3 scripts/03_led_resistor.py
Outputs: netlists/03_*.cir, renders/03_led_sweep.png, 03_resistor_choice.png
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from spice_helpers import run_netlist, load, REN

TEAL, ORANGE, NAVY, GOLD = "#2a7f62", "#d96a2b", "#26384a", "#c79a12"

# a simple red-LED model (forward voltage ~1.8-2.0 V around 10-20 mA)
LED = ".model LED D(Is=1e-20 N=1.8 Rs=2)"

# ---------- (a) fixed 220 ohm resistor, sweep the supply ----------
Rfixed = 220.0
run_netlist("03_supplysweep", f"""* LED + {Rfixed} ohm resistor, sweep supply
Vs in 0 DC 0
R1 in a {Rfixed}
Dled a 0 LED
{LED}
.dc Vs 0 6 0.2
.control
run
wrdata {os.path.join('data','03_supplysweep.txt')} i(Vs) v(a)
.endc
.end
""")
d = load("03_supplysweep")
vs, i_led, v_led = d[:, 0], -d[:, 1] * 1000, d[:, 3]   # mA, and LED node voltage

fig, ax1 = plt.subplots(figsize=(10.5, 5.5))
ax1.plot(vs, i_led, color=TEAL, lw=2.6, label="LED current")
ax1.axhline(20, color=ORANGE, lw=1.2, ls="--", label="20 mA (typical max)")
ax1.set_xlabel("supply voltage (V)"); ax1.set_ylabel("LED current (mA)", color=TEAL)
ax1.tick_params(axis="y", labelcolor=TEAL); ax1.grid(alpha=0.25)
ax1.annotate("LED only starts conducting\nonce supply > forward voltage",
             xy=(2.0, 1), xytext=(2.4, 9), fontsize=9.5, color="#444",
             arrowprops=dict(arrowstyle="->", color="#888"))
ax2 = ax1.twinx()
ax2.plot(vs, v_led, color=NAVY, lw=1.8, ls="-.", label="LED forward voltage")
ax2.set_ylabel("LED forward voltage (V)", color=NAVY); ax2.tick_params(axis="y", labelcolor=NAVY)
ax1.set_title(f"LED with a {Rfixed:.0f} $\\Omega$ resistor -- current vs supply",
              fontsize=13, weight="bold")
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc="upper left")
fig.tight_layout(); fig.savefig(os.path.join(REN, "03_led_sweep.png"), dpi=130)
plt.close(fig)
# report current at 5 V
i_at_5 = np.interp(5.0, vs, i_led)
print("at 5 V supply with %.0f ohm: LED current = %.1f mA" % (Rfixed, i_at_5))


# ---------- (b) fix 5 V supply, sweep the resistor to hit a target ----------
Vsupply = 5.0
R_values = np.array([100, 150, 220, 330, 470, 680, 1000])
currents = []
for Rv in R_values:
    nm = "03_R%d" % int(Rv)
    run_netlist(nm, f"""* LED, 5V supply, R={Rv}
Vs in 0 DC {Vsupply}
R1 in a {Rv}
Dled a 0 LED
{LED}
.op
.control
run
print i(Vs) > {os.path.join('data', nm + '.txt')}
.endc
.end
""")
    with open(os.path.join("data", nm + ".txt")) as f:
        txt = f.read()
    # grab the last number on the i(Vs) line
    cur = None
    for line in txt.splitlines():
        if "i(vs)" in line.lower() or "i(Vs)" in line:
            cur = abs(float(line.split()[-1])) * 1000
    currents.append(cur)

currents = np.array(currents)
fig, ax = plt.subplots(figsize=(10.5, 5.5))
ax.plot(R_values, currents, "o-", color=TEAL, markersize=8, lw=2)
ax.axhspan(10, 20, alpha=0.08, color=TEAL)
ax.text(700, 15, "typical safe\noperating band\n(10-20 mA)", fontsize=9, color=TEAL)
for Rv, cur in zip(R_values, currents):
    ax.annotate(f"{cur:.0f} mA", (Rv, cur), textcoords="offset points",
                xytext=(0, 9), ha="center", fontsize=8.5)
ax.set_xlabel("series resistor (ohms)"); ax.set_ylabel("LED current (mA)")
ax.set_title("Choosing the resistor -- LED current at a 5 V supply",
             fontsize=13, weight="bold")
ax.grid(alpha=0.25)
fig.tight_layout(); fig.savefig(os.path.join(REN, "03_resistor_choice.png"), dpi=130)
plt.close(fig)
print("resistor sweep (ohm -> mA):",
      {int(r): round(c, 1) for r, c in zip(R_values, currents)})
# the rule-of-thumb pick: R = (5 - 1.9)/0.015 ~ 207 ohm for ~15 mA
print("rule of thumb R for 15 mA: %.0f ohm (220 ohm gives %.0f mA)"
      % ((5 - 1.9) / 0.015, currents[list(R_values).index(220)]))
print("done 03")
