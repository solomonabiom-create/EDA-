"""
Helpers to write a SPICE netlist, run Ngspice in batch mode, and read results.
Shared by the circuit-fundamentals portfolio scripts.
"""
import os
import subprocess
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
NET = os.path.join(ROOT, "netlists")
DATA = os.path.join(ROOT, "data")
REN = os.path.join(ROOT, "renders")
for d in (NET, DATA, REN):
    os.makedirs(d, exist_ok=True)


def run_netlist(name, netlist_text):
    cir = os.path.join(NET, name + ".cir")
    with open(cir, "w") as f:
        f.write(netlist_text)
    r = subprocess.run(["ngspice", "-b", cir], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("ngspice failed for %s:\n%s" % (name, r.stderr[-800:]))
    return r.stdout


def load(name):
    return np.loadtxt(os.path.join(DATA, name + ".txt"))
