"""
Project 2 -- RC filter: smoothing a noisy sensor signal
A first-order RC low-pass filter is the most common building block an engineer
meets for cleaning up a measurement signal (think a noisy sensor reading). Two
views, both from Ngspice:

  (a) frequency response -- how the filter passes low frequencies and rejects
      high ones, with the -3 dB cut-off where fc = 1 / (2 pi R C).
  (b) step response      -- in the time domain, how the output settles after a
      sudden input change, set by the time constant tau = R C.

Run:     python3 scripts/02_rc_filter.py
Outputs: netlists/02_*.cir, renders/02_rc_response.png, 02_rc_step.png
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from spice_helpers import run_netlist, load, REN

TEAL, ORANGE, NAVY, GOLD = "#2a7f62", "#d96a2b", "#26384a", "#c79a12"

R = 1592.0
C = 100e-9
fc = 1 / (2 * np.pi * R * C)      # ~ 1 kHz
tau = R * C                        # time constant

# ---------- (a) frequency response ----------
run_netlist("02_freq", f"""* RC low-pass frequency response, fc={fc:.0f} Hz
V1 in 0 AC 1
R1 in out {R}
C1 out 0 {C}
.ac dec 60 10 1meg
.control
run
wrdata {os.path.join('data','02_freq.txt')} vdb(out)
.endc
.end
""")
d = load("02_freq")
f, db = d[:, 0], d[:, 1]

fig, ax = plt.subplots(figsize=(10.5, 5.5))
ax.semilogx(f, db, color=TEAL, lw=2.6)
ax.axhline(-3, color="#999", lw=0.9); ax.axvline(fc, color="#999", lw=0.9)
ax.annotate(f"-3 dB cut-off\nfc = {fc:.0f} Hz", xy=(fc, -3), xytext=(fc * 1.5, -14),
            fontsize=10, color="#444",
            arrowprops=dict(arrowstyle="->", color="#888"))
ax.fill_betweenx([-60, 5], 10, fc, alpha=0.06, color=TEAL)
ax.text(40, 2, "passband\n(signal kept)", fontsize=9, color=TEAL)
ax.text(2e4, 2, "stopband\n(noise rejected)", fontsize=9, color=ORANGE)
ax.set_xlim(10, 1e6); ax.set_ylim(-60, 5)
ax.set_xlabel("frequency (Hz)"); ax.set_ylabel("output / input (dB)")
ax.set_title("RC low-pass filter -- frequency response", fontsize=14, weight="bold")
ax.grid(True, which="both", alpha=0.25)
fig.tight_layout(); fig.savefig(os.path.join(REN, "02_rc_response.png"), dpi=130)
plt.close(fig)
# confirm cut-off
idx = np.argmin(np.abs(db - (-3)))
print("RC filter -3 dB at %.0f Hz (theory %.0f Hz)" % (f[idx], fc))

# ---------- (b) step response (time domain) ----------
run_netlist("02_step", f"""* RC step response, tau = R*C = {tau*1e3:.3f} ms
V1 in 0 PULSE(0 1 0.1m 1u 1u 5m 10m)
R1 in out {R}
C1 out 0 {C}
.tran 5u 3m
.control
run
wrdata {os.path.join('data','02_step.txt')} v(out) v(in)
.endc
.end
""")
s = load("02_step")
t, vout, vin = s[:, 0] * 1000, s[:, 1], s[:, 3]

fig, ax = plt.subplots(figsize=(10.5, 5.5))
ax.plot(t, vin, color="#bbb", lw=1.5, label="input (step)")
ax.plot(t, vout, color=TEAL, lw=2.6, label="output (smoothed)")
# mark one time constant: output reaches ~63.2% of final value at t = tau
tau_ms = tau * 1000
ax.axvline(0.1 + tau_ms, color=ORANGE, lw=1.2, ls="--")
ax.axhline(0.632, color="#ccc", lw=0.8)
ax.annotate(f"1 time constant\n$\\tau$ = R C = {tau_ms:.2f} ms\n(63% of final)",
            xy=(0.1 + tau_ms, 0.632), xytext=(0.1 + tau_ms + 0.5, 0.40),
            fontsize=9.5, color="#444",
            arrowprops=dict(arrowstyle="->", color="#888"))
ax.set_xlabel("time (ms)"); ax.set_ylabel("voltage (V)")
ax.set_title("RC low-pass -- step response and the R C time constant",
             fontsize=14, weight="bold")
ax.legend(fontsize=10, loc="lower right"); ax.grid(alpha=0.25)
ax.set_xlim(0, 3)
fig.tight_layout(); fig.savefig(os.path.join(REN, "02_rc_step.png"), dpi=130)
plt.close(fig)

# verify the 63% point
final = vout[-1]
target = 0.632 * 1.0
# find time after the edge (0.1 ms) where output crosses 63.2%
after = t > 0.1
tcross = t[after][np.argmin(np.abs(vout[after] - target))]
print("step: output hits 63%% at t = %.3f ms after edge (tau = %.3f ms)"
      % (tcross - 0.1, tau_ms))
print("done 02")
