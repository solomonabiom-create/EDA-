# Circuit Fundamentals Notebook (Ngspice)

**Solomon Abiom** · Glasgow, UK · solomonabiom@gmail.com

A learner's notebook working through electrical-engineering circuit fundamentals in **Ngspice** circuit simulation. Three worked entries, each checked against the textbook formula it should follow. The page is **`index.html`** (self-contained: all figures embedded, opens anywhere, works as GitHub Pages). Netlists are standard SPICE and also run in **LTspice**.

This is an honest starting point — circuit theory from a civil-engineering degree put into practice with the simulation tools, not a claim of professional EDA experience.

| Entry | Topic | Checked against |
|---|---|---|
| 01 | Ohm's law & Kirchhoff's voltage law | I = V/R slope matches 1/R to 4 dp; divider voltages sum to the 9 V supply |
| 02 | RC low-pass filter (frequency + step response) | −3 dB at exactly 1000 Hz; 63% reached at one time constant τ = RC |
| 03 | Sizing an LED current-limiting resistor | 220 Ω → ~14 mA at 5 V, inside the safe 10–20 mA band, matching the hand calculation |

## Reproduce everything

```
# install Ngspice (https://ngspice.sourceforge.io) — e.g. apt install ngspice
pip install numpy matplotlib

python3 scripts/01_ohms_kirchhoff.py
python3 scripts/02_rc_filter.py
python3 scripts/03_led_resistor.py
python3 scripts/build_site.py        # rebuilds index.html from the figures
```

Netlists are written to `netlists/`, data to `data/`, figures to `renders/`.

## Repo layout

```
index.html        the notebook page (self-contained — also works as GitHub Pages)
scripts/          one script per entry + shared SPICE helpers + the site builder
netlists/         generated .cir SPICE netlists
data/             simulation output
renders/          the figures
```

## About

Civil engineering graduate (B.Eng) completing an MSc in Project Management in Glasgow. Electrical and circuit theory was part of my engineering foundation; this notebook is where I'm putting that grounding into practice with circuit-simulation tools — describing each circuit, simulating it, and checking the result against the formula it should follow. Foundations done properly, with room to build.
